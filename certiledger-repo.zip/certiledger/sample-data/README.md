# Sample Data
- `students.csv`, `results.csv`, `users.csv`: demo records (all fictional).
- `certificates/`: small text stand-ins for certificate PDFs.
- `certificates.json`: simulated on-chain records with real SHA-512 hashes of the files above.
  - CL-2026-0001 -> Verified
  - CL-2026-0002 -> Revoked
  - CL-2026-0003 -> Invalid (stored hash does not match the file)

The CIDs are placeholders, not real IPFS content.
